import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, test } from "bun:test";

import { accessTokenIsFresh, VeraClient } from "./client.js";
import { readState, writeState } from "./state.js";

const cleanup = [];
afterEach(async () => {
  await Promise.all(cleanup.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

async function testEnv() {
  const root = await mkdtemp(join(tmpdir(), "letta-vera-client-"));
  cleanup.push(root);
  return {
    VERA_LETTA_STATE_PATH: join(root, "connection.json"),
    VERA_COWORK_ENV_PATH: join(root, "cowork.env"),
    VERA_SERVER_URL: "https://vera.example.com",
  };
}

function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function nativeMcpResult(result) {
  return json({ jsonrpc: "2.0", id: "letta-code-vera", result });
}

function nativeMcpTools(tools = []) {
  return nativeMcpResult({ tools });
}

function jwt(expiresAtSeconds) {
  const encode = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
  return `${encode({ alg: "none" })}.${encode({ exp: expiresAtSeconds })}.signature`;
}

describe("VeraClient", () => {
  test("performs staged email OTP login and authenticates capability requests", async () => {
    const env = await testEnv();
    const requests = [];
    const accessToken = jwt(Math.floor(Date.now() / 1000) + 3600);
    const fetch = async (url, init) => {
      requests.push({ url, init });
      const path = new URL(url).pathname;
      if (path === "/auth/otp/request") return json({ success: true });
      if (path === "/auth/otp/verify") {
        return json({
          accessToken,
          refreshToken: "refresh-1",
          user: { email: "user@verivolt.com" },
          currentOrganization: { name: "Verivolt" },
        });
      }
      if (path === "/mcp/tools") {
        return json([{ name: "odoo__search", description: "Search Odoo", parameters: {} }]);
      }
      if (path === "/mcp") return nativeMcpTools();
      return json({ message: "not found" }, 404);
    };
    const client = new VeraClient({ env, fetch });

    await client.requestOtp("User@Verivolt.com");
    expect((await readState(env)).pendingEmail).toBe("user@verivolt.com");

    const auth = await client.verifyOtp("123456");
    expect(auth.refreshToken).toBe("refresh-1");
    expect((await readState(env)).pendingEmail).toBeNull();

    const tools = await client.listMcpTools();
    expect(tools[0].name).toBe("odoo__search");
    expect(requests.at(-1).init.headers.get("authorization")).toBe(
      `Bearer ${accessToken}`,
    );
    expect(JSON.parse(requests[0].init.body)).toEqual({
      email: "user@verivolt.com",
    });
  });

  test("uses the current token from cowork.env before Letta Code-managed auth", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    await writeState(
      {
        version: 1,
        serverUrl: "https://vera.example.com",
        pendingEmail: null,
        auth: { accessToken: "local-access-token", refreshToken: "local-refresh-token" },
      },
      env,
    );

    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return new URL(url).pathname === "/mcp" ? nativeMcpTools() : json([]);
      },
    });

    await client.listMcpTools();

    expect(requests).toHaveLength(3);
    expect(
      requests.every(
        (request) =>
          request.init.headers.get("authorization") === "Bearer cowork-access-token",
      ),
    ).toBe(true);
    expect((await client.getConnectionInfo()).source).toBe("cowork");
  });

  test("re-reads cowork.env and retries once when Cowork rotates the token", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-token-1\n",
      "utf8",
    );

    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        if (requests.length === 1) {
          await writeFile(
            env.VERA_COWORK_ENV_PATH,
            "export COWORK_TOKEN=cowork-token-2\n",
            "utf8",
          );
          return json({ message: "expired" }, 401);
        }
        return new URL(url).pathname === "/mcp" ? nativeMcpTools() : json([]);
      },
    });

    await client.listMcpTools();

    expect(requests).toHaveLength(4);
    expect(requests[0].init.headers.get("authorization")).toBe(
      "Bearer cowork-token-1",
    );
    expect(
      requests.slice(1).every(
        (request) => request.init.headers.get("authorization") === "Bearer cowork-token-2",
      ),
    ).toBe(true);
  });

  test("does not revoke a Cowork-managed session during Vera disconnect", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return json({ success: true });
      },
    });

    const result = await client.logout();

    expect(result).toEqual({ coworkManaged: true, hadLocalAuth: false });
    expect(requests).toHaveLength(0);
    expect((await client.getConnectionInfo()).source).toBe("cowork");
  });

  test("rotates an expired access and refresh token before requesting tools", async () => {
    const env = await testEnv();
    const expiredToken = jwt(Math.floor(Date.now() / 1000) - 10);
    const freshToken = jwt(Math.floor(Date.now() / 1000) + 3600);
    await writeState(
      {
        version: 1,
        serverUrl: "https://vera.example.com",
        pendingEmail: null,
        auth: {
          accessToken: expiredToken,
          refreshToken: "refresh-old",
          refreshTokenExpiresAt: null,
          user: null,
          currentOrganization: null,
        },
      },
      env,
    );

    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        const path = new URL(url).pathname;
        if (path === "/auth/refresh") {
          return json({ accessToken: freshToken, refreshToken: "refresh-new" });
        }
        if (path === "/mcp/tools") return json([]);
        if (path === "/mcp") return nativeMcpTools();
        return json({}, 404);
      },
    });

    await client.listMcpTools();

    expect(requests.map(({ url }) => new URL(url).pathname)).toEqual([
      "/auth/refresh",
      "/mcp/tools",
      "/mcp",
      "/neo4j-mcp",
    ]);
    expect(JSON.parse(requests[0].init.body)).toEqual({
      refreshToken: "refresh-old",
    });
    expect(requests[1].init.headers.get("authorization")).toBe(
      `Bearer ${freshToken}`,
    );
    expect((await readState(env)).auth.refreshToken).toBe("refresh-new");
  });

  test("logs out with the rotated refresh token and clears local auth", async () => {
    const env = await testEnv();
    await writeState(
      {
        version: 1,
        serverUrl: "https://vera.example.com",
        pendingEmail: null,
        auth: {
          accessToken: jwt(Math.floor(Date.now() / 1000) - 10),
          refreshToken: "refresh-old",
        },
      },
      env,
    );
    const freshToken = jwt(Math.floor(Date.now() / 1000) + 3600);
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        if (new URL(url).pathname === "/auth/refresh") {
          return json({ accessToken: freshToken, refreshToken: "refresh-new" });
        }
        return json({ success: true });
      },
    });

    await client.logout();

    expect(requests.map(({ url }) => new URL(url).pathname)).toEqual([
      "/auth/refresh",
      "/auth/logout",
    ]);
    expect(JSON.parse(requests[1].init.body)).toEqual({
      refreshToken: "refresh-new",
    });
    expect(requests[1].init.headers.get("authorization")).toBe(
      `Bearer ${freshToken}`,
    );
    expect((await readState(env)).auth).toBeNull();
  });

  test("detects token freshness without exposing claims", () => {
    const now = Math.floor(Date.now() / 1000);
    expect(accessTokenIsFresh(jwt(now + 120), now)).toBe(true);
    expect(accessTokenIsFresh(jwt(now + 20), now)).toBe(false);
    expect(accessTokenIsFresh("opaque-token", now)).toBe(true);
  });

  test("parses MCP tool catalogs larger than the response preview limit", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    const catalog = Array.from({ length: 163 }, (_, index) => ({
      name: `connector__tool_${index}`,
      description: "Large MCP tool description ".repeat(10),
      parameters: {
        type: "object",
        properties: { query: { type: "string", description: "Search query" } },
      },
    }));
    expect(JSON.stringify(catalog).length).toBeGreaterThan(20_000);

    const client = new VeraClient({
      env,
      fetch: async (url) =>
        new URL(url).pathname === "/mcp" ? nativeMcpTools() : json(catalog),
    });

    const tools = await client.listMcpTools();

    expect(tools).toHaveLength(163);
    expect(tools.at(-1).name).toBe("connector__tool_162");
  });

  test("merges native Vera tools with connector tools", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        const path = new URL(url).pathname;
        if (path === "/mcp") {
          return nativeMcpTools([
            {
              name: "vera_list_remote_machines",
              description: "List connected Cowork computers",
              inputSchema: { type: "object", properties: {} },
            },
            {
              name: "vera_run_remote_tool",
              description: "Run a connected-computer tool",
              inputSchema: {
                type: "object",
                properties: { environmentId: { type: "string" } },
              },
            },
          ]);
        }
        if (path === "/neo4j-mcp") {
          return nativeMcpTools([
            {
              name: "neo4j_list_instances",
              description: "List visible graph instances",
              inputSchema: { type: "object", properties: {} },
            },
            {
              name: "neo4j_read",
              description: "Run bounded Cypher",
              inputSchema: {
                type: "object",
                properties: { instance: { type: "string" }, cypher: { type: "string" } },
              },
            },
          ]);
        }
        return json([
          {
            name: "odoo__search",
            description: "Search Odoo",
            parameters: { type: "object", properties: {} },
          },
        ]);
      },
    });

    const tools = await client.listMcpTools();

    expect(tools.map((tool) => tool.name)).toEqual([
      "vera_list_remote_machines",
      "vera_run_remote_tool",
      "neo4j_list_instances",
      "neo4j_read",
      "odoo__search",
    ]);
    expect(tools[1].parameters.properties.environmentId.type).toBe("string");
    expect(tools[3].parameters.properties.cypher.type).toBe("string");
    expect(requests.map(({ url }) => new URL(url).pathname)).toEqual([
      "/mcp/tools",
      "/mcp",
      "/neo4j-mcp",
    ]);
    expect(JSON.parse(requests[1].init.body)).toMatchObject({
      jsonrpc: "2.0",
      method: "tools/list",
      params: {},
    });
  });

  test("routes native Vera tool calls through the stateless MCP endpoint", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return nativeMcpResult({
          content: [{ type: "text", text: '{"count":1}' }],
          isError: false,
        });
      },
    });

    const result = await client.invokeMcpTool(
      "vera_list_remote_machines",
      {},
    );

    expect(result).toEqual({ output: '{"count":1}', isError: false });
    expect(new URL(requests[0].url).pathname).toBe("/mcp");
    expect(JSON.parse(requests[0].init.body)).toMatchObject({
      jsonrpc: "2.0",
      method: "tools/call",
      params: { name: "vera_list_remote_machines", arguments: {} },
    });
  });

  test("routes governed Neo4j tool calls through the Neo4j MCP endpoint", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return nativeMcpResult({
          content: [{ type: "text", text: '{"records":[{"name":"Acme"}]}' }],
          isError: false,
        });
      },
    });

    const result = await client.invokeMcpTool("neo4j_read", {
      instance: "operations-graph",
      cypher: "MATCH (c:Customer) RETURN c.name AS name LIMIT 1",
      maxRecords: 1,
    });

    expect(result).toEqual({
      output: '{"records":[{"name":"Acme"}]}',
      isError: false,
    });
    expect(new URL(requests[0].url).pathname).toBe("/neo4j-mcp");
    expect(JSON.parse(requests[0].init.body)).toMatchObject({
      jsonrpc: "2.0",
      method: "tools/call",
      params: {
        name: "neo4j_read",
        arguments: {
          instance: "operations-graph",
          maxRecords: 1,
        },
      },
    });
  });

  test("keeps namespaced connector calls on the connector runtime endpoint", async () => {
    const env = await testEnv();
    await writeFile(
      env.VERA_COWORK_ENV_PATH,
      "export COWORK_TOKEN=cowork-access-token\n",
      "utf8",
    );
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return json({ output: "connector result", isError: false });
      },
    });

    const result = await client.invokeMcpTool("odoo__search", { limit: 1 });

    expect(result).toEqual({ output: "connector result", isError: false });
    expect(new URL(requests[0].url).pathname).toBe("/mcp/tools/invoke");
    expect(JSON.parse(requests[0].init.body)).toEqual({
      toolName: "odoo__search",
      args: { limit: 1 },
    });
  });

  test("uses normal Vera user endpoints for organization-agent delegation", async () => {
    const env = await testEnv();
    const accessToken = jwt(Math.floor(Date.now() / 1000) + 3600);
    await writeState(
      {
        version: 1,
        serverUrl: "https://vera.example.com",
        pendingEmail: null,
        auth: { accessToken, refreshToken: "refresh" },
      },
      env,
    );
    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return new URL(url).pathname === "/agent-communication/available-agents"
          ? json({
              summary: { total: 1 },
              agents: [
                {
                  publicationId: "publisher-org:agent-specialist",
                  organizationId: "publisher-org",
                  organizationName: "Publisher",
                  agentId: "agent-specialist",
                  sameOrganization: false,
                  grantedThrough: "trusted_member",
                },
              ],
            })
          : json({ conversationId: "conversation-1" });
      },
    });

    await expect(client.listOrganizationAgents()).resolves.toHaveLength(1);
    await client.delegateToOrganizationAgent({
      agentId: "agent-specialist",
      description: "Review task",
      prompt: "Please review this task",
    });

    expect(new URL(requests[0].url).pathname).toBe(
      "/agent-communication/available-agents",
    );
    expect(new URL(requests[1].url).pathname).toBe(
      "/agent-communication/available-agents",
    );
    expect(new URL(requests[2].url).pathname).toBe(
      "/agent-communication/send",
    );
    expect(JSON.parse(requests[2].init.body)).toEqual({
      publicationId: "publisher-org:agent-specialist",
      message: "Please review this task",
    });
  });

  test("uses exact Vera MCP invocation and channel send contracts", async () => {
    const env = await testEnv();
    const accessToken = jwt(Math.floor(Date.now() / 1000) + 3600);
    await writeState(
      {
        version: 1,
        serverUrl: "https://vera.example.com",
        pendingEmail: null,
        auth: { accessToken, refreshToken: "refresh" },
      },
      env,
    );

    const requests = [];
    const client = new VeraClient({
      env,
      fetch: async (url, init) => {
        requests.push({ url, init });
        return json({ ok: true });
      },
    });

    await client.invokeMcpTool("odoo__search", { model: "sale.order" });
    await client.sendChannelMessage("channel-id", {
      to: "recipient",
      content: "Hello",
      conversationId: "thread-id",
    });

    expect(JSON.parse(requests[0].init.body)).toEqual({
      toolName: "odoo__search",
      args: { model: "sale.order" },
    });
    expect(new URL(requests[1].url).pathname).toBe("/channels/channel-id/send");
    expect(JSON.parse(requests[1].init.body)).toMatchObject({
      to: "recipient",
      content: "Hello",
      conversationId: "thread-id",
      toolName: "vera_channel_send",
    });
  });
});
